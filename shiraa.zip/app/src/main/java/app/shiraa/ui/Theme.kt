package app.shiraa.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object ShiraaColors {
    val Background = Color(0xFF0B0B0D)
    val Surface = Color(0xFF16171A)
    val Glass = Color(0x33FFFFFF)
    val GlassBorder = Color(0x22FFFFFF)
    val Accent = Color(0xFFE6E6EA)
    val TextDim = Color(0xFF9A9BA3)
}

@Composable
fun ShiraaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = ShiraaColors.Background,
            surface = ShiraaColors.Surface,
            primary = ShiraaColors.Accent,
            onBackground = ShiraaColors.Accent,
            onSurface = ShiraaColors.Accent
        ),
        content = content
    )
}
