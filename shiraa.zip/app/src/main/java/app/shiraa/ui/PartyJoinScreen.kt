package app.shiraa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.shiraa.data.Party
import app.shiraa.data.Room
import kotlinx.coroutines.launch

@Composable
fun PartyJoinScreen(onJoin: (String, Room) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var code by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(ShiraaColors.Background)) {
        Column(Modifier.padding(32.dp), verticalArrangement = Arrangement.Center) {
            Text("الانضمام لغرفة مشاهدة", color = ShiraaColors.Accent, fontSize = 26.sp)
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = code,
                onValueChange = { if (it.length <= 5 && it.all(Char::isDigit)) code = it },
                label = { Text("رمز الغرفة") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassButton(if (busy) "جاري البحث..." else "انضم") {
                    if (code.length == 5 && !busy) {
                        scope.launch {
                            busy = true
                            val r = Party.get(ctx, code)
                            busy = false
                            if (r == null) msg = "ما لقيت الغرفة. تأكد من الرمز ومن إعدادات Firebase"
                            else onJoin(code, r)
                        }
                    }
                }
                GlassButton("رجوع") { onBack() }
            }
            if (msg.isNotBlank()) Text(msg, color = ShiraaColors.TextDim, fontSize = 13.sp)
        }
    }
}
