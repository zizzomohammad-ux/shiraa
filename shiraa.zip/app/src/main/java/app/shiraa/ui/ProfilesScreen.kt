package app.shiraa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.shiraa.data.Avatars
import app.shiraa.data.Profile
import app.shiraa.data.Profiles
import coil.compose.AsyncImage

@Composable
fun ProfilesScreen(onSelect: (Profile) -> Unit) {
    val ctx = LocalContext.current
    var profiles by remember { mutableStateOf(Profiles.list(ctx)) }
    var adding by remember { mutableStateOf(profiles.isEmpty()) }
    var pinFor by remember { mutableStateOf<Profile?>(null) }
    var manage by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(ShiraaColors.Background)) {
        when {
            adding -> AddProfile(
                canCancel = profiles.isNotEmpty(),
                onCancel = { adding = false },
                onSave = { n, a, p ->
                    Profiles.add(ctx, n, a, p)
                    profiles = Profiles.list(ctx)
                    adding = false
                }
            )
            pinFor != null -> PinEntry(
                profile = pinFor!!,
                onOk = { onSelect(pinFor!!) },
                onCancel = { pinFor = null }
            )
            else -> Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("من يشاهد؟", color = ShiraaColors.Accent, fontSize = 30.sp)
                Spacer(Modifier.height(24.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    items(profiles) { p ->
                        AvatarTile(p, manage) {
                            if (manage) {
                                Profiles.remove(ctx, p.id)
                                profiles = Profiles.list(ctx)
                                if (profiles.isEmpty()) adding = true
                            } else if (p.pinHash != null) pinFor = p
                            else onSelect(p)
                        }
                    }
                    item {
                        GlassButton("+ حساب جديد") { adding = true }
                    }
                }
                Spacer(Modifier.height(24.dp))
                GlassButton(if (manage) "تم" else "إدارة الحسابات") { manage = !manage }
                if (manage) Text("اضغط على أي حساب لحذفه", color = ShiraaColors.TextDim, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun AvatarTile(p: Profile, danger: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        AsyncImage(
            model = p.avatar,
            contentDescription = p.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(110.dp)
                .clip(CircleShape)
                .background(ShiraaColors.Surface)
                .border(if (focused) 4.dp else 1.dp, if (danger) Color.Red else if (focused) ShiraaColors.Accent else ShiraaColors.GlassBorder, CircleShape)
                .onFocusChanged { focused = it.isFocused }
                .clickable { onClick() }
                .focusable()
        )
        Spacer(Modifier.height(8.dp))
        Text(p.name + if (p.pinHash != null) " 🔒" else "", color = ShiraaColors.Accent, fontSize = 15.sp)
    }
}

@Composable
fun AddProfile(canCancel: Boolean, onCancel: () -> Unit, onSave: (String, String, String?) -> Unit) {
    var name by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var avatars by remember { mutableStateOf<List<String>>(emptyList()) }
    var avatar by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        avatars = Avatars.load()
        if (avatars.isNotEmpty()) avatar = avatars.first()
    }

    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center) {
        Text("حساب جديد", color = ShiraaColors.Accent, fontSize = 26.sp)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("الاسم") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = pin,
            onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) pin = it },
            label = { Text("رمز من 4 أرقام (اختياري)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(14.dp))
        Text(if (avatars.isEmpty()) "جاري تحميل الصور..." else "اختر صورة", color = ShiraaColors.TextDim)
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(avatars) { url ->
                var focused by remember { mutableStateOf(false) }
                AsyncImage(
                    model = url,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(70.dp)
                        .clip(CircleShape)
                        .background(ShiraaColors.Surface)
                        .border(if (url == avatar) 4.dp else if (focused) 2.dp else 1.dp, if (url == avatar || focused) ShiraaColors.Accent else ShiraaColors.GlassBorder, CircleShape)
                        .onFocusChanged { focused = it.isFocused }
                        .clickable { avatar = url }
                        .focusable()
                )
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassButton("حفظ") {
                if (name.isNotBlank() && (pin.isEmpty() || pin.length == 4)) onSave(name.trim(), avatar, pin.ifBlank { null })
            }
            if (canCancel) GlassButton("إلغاء") { onCancel() }
        }
    }
}

@Composable
fun PinEntry(profile: Profile, onOk: () -> Unit, onCancel: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("أدخل رمز ${profile.name}", color = ShiraaColors.Accent, fontSize = 22.sp)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = pin,
            onValueChange = {
                if (it.length <= 4 && it.all(Char::isDigit)) {
                    pin = it
                    wrong = false
                    if (it.length == 4) {
                        if (Profiles.checkPin(profile, it)) onOk() else { wrong = true; pin = "" }
                    }
                }
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true
        )
        if (wrong) Text("الرمز غلط", color = Color.Red, fontSize = 14.sp)
        Spacer(Modifier.height(14.dp))
        GlassButton("رجوع") { onCancel() }
    }
}
