package app.shiraa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.shiraa.data.Addons

@Composable
fun AddonsScreen(profile: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var urls by remember { mutableStateOf(Addons.list(ctx, profile)) }
    var input by remember { mutableStateOf("") }

    Box(Modifier.fillMaxSize().background(ShiraaColors.Background)) {
        Column(Modifier.padding(24.dp)) {
            Text("الإضافات", color = ShiraaColors.Accent, fontSize = 28.sp)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text("الصق رابط الإضافة هنا") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GlassButton("إضافة") {
                    if (input.isNotBlank()) {
                        Addons.add(ctx, profile, input)
                        urls = Addons.list(ctx, profile)
                        input = ""
                    }
                }
                GlassButton("رجوع") { onBack() }
            }
            Spacer(Modifier.height(16.dp))
            LazyColumn {
                items(urls) { u ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(u.take(48) + "...", color = ShiraaColors.TextDim, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        GlassButton("حذف") {
                            Addons.remove(ctx, profile, u)
                            urls = Addons.list(ctx, profile)
                        }
                    }
                }
            }
        }
    }
}
