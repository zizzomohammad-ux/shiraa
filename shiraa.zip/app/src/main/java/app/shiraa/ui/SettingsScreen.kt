package app.shiraa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.shiraa.data.AppSettings
import app.shiraa.data.Trakt
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var firebase by remember { mutableStateOf(AppSettings.get(ctx, "firebase")) }
    var traktId by remember { mutableStateOf(AppSettings.get(ctx, "traktId")) }
    var traktSecret by remember { mutableStateOf(AppSettings.get(ctx, "traktSecret")) }
    var size by remember { mutableStateOf(AppSettings.subSize(ctx)) }
    var traktMsg by remember { mutableStateOf(if (Trakt.loggedIn(ctx)) "مربوط بحساب تراكت" else "غير مربوط") }
    var saved by remember { mutableStateOf(false) }

    fun save() {
        AppSettings.set(ctx, "firebase", firebase.trim())
        AppSettings.set(ctx, "traktId", traktId.trim())
        AppSettings.set(ctx, "traktSecret", traktSecret.trim())
        AppSettings.set(ctx, "subSize", size.toString())
    }

    Box(Modifier.fillMaxSize().background(ShiraaColors.Background)) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(24.dp)) {
            Text("الإعدادات", color = ShiraaColors.Accent, fontSize = 28.sp)
            Spacer(Modifier.height(16.dp))

            Text("حجم الترجمة: ${size.toInt()}", color = ShiraaColors.Accent, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassButton("أصغر") { if (size > 12f) size -= 2f }
                GlassButton("أكبر") { if (size < 40f) size += 2f }
            }

            Spacer(Modifier.height(20.dp))
            Text("غرفة المشاهدة (Firebase)", color = ShiraaColors.Accent, fontSize = 16.sp)
            OutlinedTextField(
                value = firebase,
                onValueChange = { firebase = it },
                label = { Text("رابط قاعدة البيانات") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(20.dp))
            Text("تراكت (Trakt)", color = ShiraaColors.Accent, fontSize = 16.sp)
            OutlinedTextField(
                value = traktId,
                onValueChange = { traktId = it },
                label = { Text("Client ID") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = traktSecret,
                onValueChange = { traktSecret = it },
                label = { Text("Client Secret") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Text(traktMsg, color = ShiraaColors.TextDim, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassButton("ربط الحساب") {
                    save()
                    scope.launch {
                        val d = Trakt.startLogin(ctx)
                        if (d == null) {
                            traktMsg = "فشل، تأكد من Client ID"
                        } else {
                            traktMsg = "افتح ${d.url} وأدخل الكود: ${d.userCode}"
                            val ok = Trakt.pollToken(ctx, d)
                            traktMsg = if (ok) "تم الربط بنجاح" else "فشل الربط أو انتهت المهلة"
                        }
                    }
                }
                GlassButton("فك الربط") {
                    AppSettings.set(ctx, "traktToken", "")
                    traktMsg = "غير مربوط"
                }
            }

            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassButton("حفظ") {
                    save()
                    saved = true
                }
                GlassButton("رجوع") { save(); onBack() }
            }
            if (saved) Text("تم الحفظ", color = ShiraaColors.TextDim, fontSize = 13.sp)
        }
    }
}
