package app.shiraa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.shiraa.data.Library
import app.shiraa.data.Title
import app.shiraa.data.Tmdb

@Composable
fun HomeScreen(
    profile: String,
    onOpen: (Title) -> Unit,
    onAddons: () -> Unit,
    onIptv: () -> Unit,
    onParty: () -> Unit,
    onSettings: () -> Unit,
    onSwitchProfile: () -> Unit
) {
    val ctx = LocalContext.current
    var trendingMovies by remember { mutableStateOf<List<Title>>(emptyList()) }
    var trendingSeries by remember { mutableStateOf<List<Title>>(emptyList()) }
    var popularMovies by remember { mutableStateOf<List<Title>>(emptyList()) }
    var popularSeries by remember { mutableStateOf<List<Title>>(emptyList()) }
    var results by remember { mutableStateOf<List<Title>>(emptyList()) }
    var continueList by remember { mutableStateOf<List<Title>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var failed by remember { mutableStateOf(false) }

    val favs = remember {
        Library.favorites(ctx, profile).map { Title(it.id, it.type, it.name, "", it.poster, null, it.year) }
    }

    LaunchedEffect(Unit) {
        try {
            trendingMovies = Tmdb.trendingMovies()
            trendingSeries = Tmdb.trendingSeries()
            popularMovies = Tmdb.popularMovies()
            popularSeries = Tmdb.popularSeries()
        } catch (e: Exception) {
            failed = true
        }
        continueList = Library.continueWatching(ctx, profile).map {
            Title(it.tmdbId, it.type, it.name, "", it.poster, null, "")
        }
    }

    LaunchedEffect(query) {
        if (query.length >= 2) {
            try { results = Tmdb.search(query) } catch (_: Exception) {}
        } else results = emptyList()
    }

    Box(Modifier.fillMaxSize().background(ShiraaColors.Background)) {
        if (failed) {
            Text(
                "تعذر تحميل البيانات، تأكد من الإنترنت ومفتاح TMDB",
                color = ShiraaColors.TextDim,
                fontSize = 16.sp,
                modifier = Modifier.align(Alignment.Center)
            )
        } else {
            LazyColumn(Modifier.padding(top = 24.dp)) {
                item {
                    Text("شِراع", color = ShiraaColors.Accent, fontSize = 30.sp, modifier = Modifier.padding(horizontal = 24.dp))
                    Spacer(Modifier.height(8.dp))
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item { GlassButton("الإضافات") { onAddons() } }
                        item { GlassButton("بث مباشر") { onIptv() } }
                        item { GlassButton("انضم لغرفة") { onParty() } }
                        item { GlassButton("الإعدادات") { onSettings() } }
                        item { GlassButton("تبديل الحساب") { onSwitchProfile() } }
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        label = { Text("ابحث عن فيلم أو مسلسل") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp)
                    )
                }
                if (results.isNotEmpty()) item { Shelf("نتائج البحث", results, onOpen) }
                if (continueList.isNotEmpty()) item { Shelf("أكمل المشاهدة", continueList, onOpen) }
                if (favs.isNotEmpty()) item { Shelf("المفضلة", favs, onOpen) }
                item { Shelf("الأفلام الرائجة", trendingMovies, onOpen) }
                item { Shelf("المسلسلات الرائجة", trendingSeries, onOpen) }
                item { Shelf("أفلام مشهورة", popularMovies, onOpen) }
                item { Shelf("مسلسلات مشهورة", popularSeries, onOpen) }
            }
        }
    }
}
