package app.shiraa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.shiraa.data.Title
import coil.compose.AsyncImage

@Composable
fun GlassButton(label: String, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (focused) ShiraaColors.Glass else ShiraaColors.Surface)
            .border(if (focused) 2.dp else 1.dp, if (focused) ShiraaColors.Accent else ShiraaColors.GlassBorder, RoundedCornerShape(10.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable { onClick() }
            .focusable()
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        Text(label, color = ShiraaColors.Accent, fontSize = 15.sp)
    }
}

@Composable
fun PosterCard(title: Title, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column(Modifier.width(130.dp)) {
        AsyncImage(
            model = title.poster,
            contentDescription = title.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .width(130.dp)
                .height(195.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(ShiraaColors.Surface)
                .border(if (focused) 3.dp else 1.dp, if (focused) ShiraaColors.Accent else ShiraaColors.GlassBorder, RoundedCornerShape(12.dp))
                .onFocusChanged { focused = it.isFocused }
                .clickable { onClick() }
                .focusable()
        )
        Spacer(Modifier.height(6.dp))
        Text(title.name, color = ShiraaColors.Accent, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(title.year, color = ShiraaColors.TextDim, fontSize = 11.sp)
    }
}

@Composable
fun Shelf(heading: String, list: List<Title>, onClick: (Title) -> Unit) {
    Column(Modifier.padding(vertical = 10.dp)) {
        Text(heading, color = ShiraaColors.Accent, fontSize = 20.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(list) { t -> PosterCard(t) { onClick(t) } }
        }
    }
}
