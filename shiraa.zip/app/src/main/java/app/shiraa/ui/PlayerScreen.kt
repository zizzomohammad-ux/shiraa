package app.shiraa.ui

import android.net.Uri
import android.util.TypedValue
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import app.shiraa.data.AppSettings
import app.shiraa.data.Library
import app.shiraa.data.Party
import app.shiraa.data.Progress
import app.shiraa.data.Room
import app.shiraa.data.SubItem
import app.shiraa.data.SubShift
import app.shiraa.data.Title
import app.shiraa.data.Trakt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    url: String,
    subs: List<SubItem>,
    profile: String,
    title: Title,
    videoId: String,
    role: String?,
    code: String?
) {
    val ctx = LocalContext.current
    val key = "${title.id}_$videoId"
    var offset by remember { mutableStateOf(0L) }
    var panel by remember { mutableStateOf(false) }
    var first by remember { mutableStateOf(true) }
    val chosen = remember {
        val ar = subs.filter { it.lang.startsWith("ar") }
        if (ar.isNotEmpty()) ar.take(3) else subs.take(3)
    }
    val player = remember { ExoPlayer.Builder(ctx).build() }

    LaunchedEffect(offset) {
        val start = if (first) {
            first = false
            if (role == "guest") 0L else Library.positionFor(ctx, profile, key).let { if (it > 15000) it else 0L }
        } else {
            player.currentPosition
        }
        val cfgs = chosen.mapIndexed { i, s ->
            val r = SubShift.prepare(ctx, s.url, offset, i.toString())
            val b = MediaItem.SubtitleConfiguration.Builder(r?.uri ?: Uri.parse(s.url))
                .setMimeType(r?.mime ?: MimeTypes.APPLICATION_SUBRIP)
                .setLanguage(if (s.lang.startsWith("ar")) "ar" else s.lang)
            if (i == 0) b.setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            b.build()
        }
        player.setMediaItem(MediaItem.Builder().setUri(url).setSubtitleConfigurations(cfgs).build(), start)
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setPreferredTextLanguage("ar").build()
        player.prepare()
        player.playWhenReady = true
    }

    if (role == "host" && code != null) {
        LaunchedEffect(Unit) {
            while (true) {
                Party.put(ctx, code, Room(url, title.name, chosen, player.currentPosition, player.isPlaying))
                delay(2000)
            }
        }
    }

    if (role == "guest" && code != null) {
        LaunchedEffect(Unit) {
            while (true) {
                delay(2000)
                val r = Party.get(ctx, code) ?: continue
                if (player.playWhenReady != r.playing) player.playWhenReady = r.playing
                val diff = kotlin.math.abs(player.currentPosition - r.pos)
                val limit = if (r.playing) 3500L else 1000L
                if (diff > limit) player.seekTo(r.pos)
            }
        }
    }

    val saveNow = {
        if (role != "guest" && player.duration > 0) {
            Library.saveProgress(
                ctx, profile,
                Progress(key, title.id, title.type, title.name, title.poster, videoId, player.currentPosition, player.duration, System.currentTimeMillis())
            )
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            saveNow()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            saveNow()
            if (role != "guest" && player.duration > 0 && player.currentPosition.toDouble() / player.duration > 0.9) {
                CoroutineScope(Dispatchers.IO).launch { Trakt.markWatched(ctx, title.type, title.id, videoId) }
            }
            player.release()
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    this.player = player
                    useController = true
                    subtitleView?.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, AppSettings.subSize(c))
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        Row(
            Modifier.align(Alignment.TopEnd).padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (role == "host") Text("رمز الغرفة: $code", color = ShiraaColors.Accent, fontSize = 16.sp)
            GlassButton("ترجمة") { panel = !panel }
        }
        if (panel) {
            Column(
                Modifier.align(Alignment.TopEnd).padding(top = 70.dp, end = 16.dp).background(ShiraaColors.Surface).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("توقيت الترجمة: ${offset / 1000.0} ث", color = ShiraaColors.Accent, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("أبكر 0.5") { offset -= 500 }
                    GlassButton("أخّر 0.5") { offset += 500 }
                    GlassButton("صفر") { offset = 0 }
                }
            }
        }
    }
}
