package app.shiraa.ui

import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import app.shiraa.data.AppSettings
import app.shiraa.data.Channel
import app.shiraa.data.Iptv

@Composable
fun IptvScreen(onPlay: (String) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var lists by remember { mutableStateOf(AppSettings.iptvLists(ctx)) }
    var input by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(lists.firstOrNull()) }
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    fun saveLists(l: List<String>) {
        lists = l
        AppSettings.set(ctx, "iptv", l.joinToString("\n"))
    }

    LaunchedEffect(selected) {
        val s = selected
        if (s != null) {
            loading = true
            channels = Iptv.load(s)
            loading = false
        } else {
            channels = emptyList()
        }
    }

    val shown = remember(channels, query) {
        val f = if (query.isBlank()) channels else channels.filter {
            it.name.contains(query, true) || it.group.contains(query, true)
        }
        f.take(300)
    }

    Box(Modifier.fillMaxSize().background(ShiraaColors.Background)) {
        LazyColumn(Modifier.padding(24.dp)) {
            item {
                Text("البث المباشر", color = ShiraaColors.Accent, fontSize = 28.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text("رابط قائمة M3U") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GlassButton("إضافة قائمة") {
                        if (input.isNotBlank()) {
                            saveLists(lists + input.trim())
                            selected = input.trim()
                            input = ""
                        }
                    }
                    GlassButton("حذف القائمة المحددة") {
                        val s = selected
                        if (s != null) {
                            saveLists(lists - s)
                            selected = lists.firstOrNull()
                        }
                    }
                    GlassButton("رجوع") { onBack() }
                }
                Spacer(Modifier.height(10.dp))
            }
            items(lists) { l ->
                Box(Modifier.padding(vertical = 3.dp)) {
                    GlassButton((if (l == selected) "● " else "○ ") + l.take(50)) { selected = l }
                }
            }
            item {
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("ابحث في القنوات") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (loading) Text("جاري تحميل القائمة...", color = ShiraaColors.TextDim)
                else if (selected != null && channels.isEmpty()) Text("ما لقيت قنوات في هذي القائمة", color = ShiraaColors.TextDim)
                Spacer(Modifier.height(8.dp))
            }
            items(shown) { c ->
                Box(Modifier.padding(vertical = 3.dp)) {
                    GlassButton((if (c.group.isNotBlank()) c.group + "  ·  " else "") + c.name) { onPlay(c.url) }
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
fun SimplePlayer(url: String) {
    val ctx = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    AndroidView(
        factory = { c -> PlayerView(c).apply { this.player = player } },
        modifier = Modifier.fillMaxSize()
    )
}
