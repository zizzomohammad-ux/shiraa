package app.shiraa.ui

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import app.shiraa.data.Party
import app.shiraa.data.StreamItem
import app.shiraa.data.SubItem
import app.shiraa.data.Title

sealed class Screen {
    object Home : Screen()
    object Addons : Screen()
    object Settings : Screen()
    object Iptv : Screen()
    object PartyJoin : Screen()
    data class Live(val url: String) : Screen()
    data class Detail(val title: Title) : Screen()
    data class Streams(val title: Title, val type: String, val videoId: String, val name: String) : Screen()
    data class Player(
        val title: Title,
        val videoId: String,
        val url: String,
        val subs: List<SubItem>,
        val back: Screen,
        val role: String?,
        val code: String?
    ) : Screen()
}

@Composable
fun AppNav(profile: String, onSwitchProfile: () -> Unit) {
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }

    BackHandler(enabled = screen !is Screen.Home) {
        screen = when (val s = screen) {
            is Screen.Player -> s.back
            is Screen.Streams -> Screen.Detail(s.title)
            is Screen.Live -> Screen.Iptv
            else -> Screen.Home
        }
    }

    when (val s = screen) {
        is Screen.Home -> HomeScreen(
            profile = profile,
            onOpen = { t -> screen = Screen.Detail(t) },
            onAddons = { screen = Screen.Addons },
            onIptv = { screen = Screen.Iptv },
            onParty = { screen = Screen.PartyJoin },
            onSettings = { screen = Screen.Settings },
            onSwitchProfile = onSwitchProfile
        )
        is Screen.Addons -> AddonsScreen(profile) { screen = Screen.Home }
        is Screen.Settings -> SettingsScreen { screen = Screen.Home }
        is Screen.Iptv -> IptvScreen(
            onPlay = { url -> screen = Screen.Live(url) },
            onBack = { screen = Screen.Home }
        )
        is Screen.Live -> SimplePlayer(s.url)
        is Screen.PartyJoin -> PartyJoinScreen(
            onJoin = { code, room ->
                screen = Screen.Player(
                    Title(0, "movie", room.title, "", null, null, ""),
                    "party", room.url, room.subs, Screen.Home, "guest", code
                )
            },
            onBack = { screen = Screen.Home }
        )
        is Screen.Detail -> DetailScreen(
            title = s.title,
            profile = profile,
            onPlay = { imdb, type, season, ep, name ->
                val vid = if (type == "series") "$imdb:$season:$ep" else imdb
                screen = Screen.Streams(s.title, type, vid, name)
            },
            onBack = { screen = Screen.Home }
        )
        is Screen.Streams -> StreamsScreen(
            profile = profile,
            type = s.type,
            videoId = s.videoId,
            name = s.name,
            onPick = { stream: StreamItem, subs: List<SubItem>, party: Boolean ->
                screen = Screen.Player(
                    s.title, s.videoId, stream.url, subs, s,
                    if (party) "host" else null,
                    if (party) Party.newCode() else null
                )
            },
            onBack = { screen = Screen.Detail(s.title) }
        )
        is Screen.Player -> PlayerScreen(s.url, s.subs, profile, s.title, s.videoId, s.role, s.code)
    }
}
