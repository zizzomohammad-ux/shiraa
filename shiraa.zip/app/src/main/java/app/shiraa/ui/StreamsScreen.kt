package app.shiraa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.shiraa.data.Addons
import app.shiraa.data.AppSettings
import app.shiraa.data.StreamItem
import app.shiraa.data.SubItem

@Composable
fun StreamsScreen(
    profile: String,
    type: String,
    videoId: String,
    name: String,
    onPick: (StreamItem, List<SubItem>, Boolean) -> Unit,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    var streams by remember { mutableStateOf<List<StreamItem>>(emptyList()) }
    var subs by remember { mutableStateOf<List<SubItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var party by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }

    LaunchedEffect(videoId) {
        streams = Addons.streams(ctx, profile, type, videoId)
        subs = Addons.subtitles(ctx, profile, type, videoId)
        loading = false
    }

    Box(Modifier.fillMaxSize().background(ShiraaColors.Background)) {
        Column(Modifier.padding(24.dp)) {
            Text(name, color = ShiraaColors.Accent, fontSize = 22.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassButton("رجوع") { onBack() }
                GlassButton(if (party) "غرفة مشاهدة: مفعّلة" else "غرفة مشاهدة: مطفأة") {
                    party = !party
                    msg = ""
                }
            }
            if (msg.isNotBlank()) Text(msg, color = ShiraaColors.TextDim, fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            if (loading) {
                Text("جاري البحث عن الروابط...", color = ShiraaColors.TextDim)
            } else if (streams.isEmpty()) {
                Text("ما لقيت روابط. تأكد إنك أضفت إضافة من شاشة الإضافات.", color = ShiraaColors.TextDim)
            } else {
                LazyColumn {
                    items(streams) { s ->
                        Box(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            GlassButton(s.title.take(90).replace("\n", " | ")) {
                                if (party && AppSettings.get(ctx, "firebase").isBlank()) {
                                    msg = "حط رابط Firebase في الإعدادات أول"
                                } else {
                                    onPick(s, subs, party)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
