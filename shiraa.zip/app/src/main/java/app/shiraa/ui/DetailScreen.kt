package app.shiraa.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.shiraa.data.Episode
import app.shiraa.data.Library
import app.shiraa.data.MdbList
import app.shiraa.data.Title
import app.shiraa.data.Tmdb
import coil.compose.AsyncImage

@Composable
fun DetailScreen(
    title: Title,
    profile: String,
    onPlay: (imdb: String, type: String, season: Int, episode: Int, name: String) -> Unit,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    var isFav by remember { mutableStateOf(Library.isFavorite(ctx, profile, title.id)) }
    var seasons by remember { mutableStateOf(1) }
    var season by remember { mutableStateOf(1) }
    var episodes by remember { mutableStateOf<List<Episode>>(emptyList()) }
    var imdb by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf(title) }
    var ratings by remember { mutableStateOf("") }

    LaunchedEffect(title.id) {
        try {
            Tmdb.byId(title.type, title.id)?.let { info = it }
            imdb = Tmdb.imdbId(title.type, title.id)
            if (title.type == "tv") seasons = Tmdb.seasonCount(title.id)
        } catch (_: Exception) {}
    }
    LaunchedEffect(title.id) {
        ratings = MdbList.ratings(title.type, title.id)
    }
    LaunchedEffect(season, title.id) {
        if (title.type == "tv") {
            try { episodes = Tmdb.episodes(title.id, season) } catch (_: Exception) {}
        }
    }

    Box(Modifier.fillMaxSize().background(ShiraaColors.Background)) {
        AsyncImage(
            model = info.backdrop,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alpha = 0.25f,
            modifier = Modifier.fillMaxWidth().height(320.dp)
        )
        LazyColumn(Modifier.padding(24.dp)) {
            item {
                Text(info.name, color = ShiraaColors.Accent, fontSize = 30.sp)
                Text(info.year, color = ShiraaColors.TextDim, fontSize = 14.sp)
                if (ratings.isNotBlank()) Text(ratings, color = ShiraaColors.Accent, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                Text(info.overview, color = ShiraaColors.Accent, fontSize = 15.sp, maxLines = 5, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (title.type == "movie") {
                        GlassButton("تشغيل") { imdb?.let { onPlay(it, "movie", 0, 0, info.name) } }
                    }
                    GlassButton(if (isFav) "في المفضلة" else "أضف للمفضلة") {
                        Library.toggleFavorite(ctx, profile, info)
                        isFav = !isFav
                    }
                    GlassButton("رجوع") { onBack() }
                }
            }
            if (title.type == "tv") {
                item {
                    Spacer(Modifier.height(16.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items((1..seasons).toList()) { s ->
                            GlassButton("الموسم $s") { season = s }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                items(episodes) { ep ->
                    EpisodeRow(ep) {
                        imdb?.let { onPlay(it, "series", season, ep.number, "${info.name} - ${ep.name}") }
                    }
                }
            }
        }
    }
}

@Composable
fun EpisodeRow(ep: Episode, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (focused) ShiraaColors.Glass else ShiraaColors.Surface)
            .border(if (focused) 2.dp else 1.dp, if (focused) ShiraaColors.Accent else ShiraaColors.GlassBorder, RoundedCornerShape(10.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable { onClick() }
            .focusable()
            .padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        AsyncImage(
            model = ep.still,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.width(150.dp).height(85.dp).clip(RoundedCornerShape(8.dp)).background(ShiraaColors.Background)
        )
        Column(Modifier.weight(1f)) {
            Text("${ep.number}. ${ep.name}", color = ShiraaColors.Accent, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(ep.overview, color = ShiraaColors.TextDim, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
    }
}
