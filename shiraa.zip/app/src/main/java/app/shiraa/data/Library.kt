package app.shiraa.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Saved(val id: Int, val type: String, val name: String, val poster: String?, val year: String)

data class Progress(
    val key: String,
    val tmdbId: Int,
    val type: String,
    val name: String,
    val poster: String?,
    val videoId: String,
    val positionMs: Long,
    val durationMs: Long,
    val updated: Long
)

object Library {
    private fun fav(ctx: Context, profile: String) = ctx.getSharedPreferences("fav_$profile", Context.MODE_PRIVATE)
    private fun prog(ctx: Context, profile: String) = ctx.getSharedPreferences("prog_$profile", Context.MODE_PRIVATE)

    fun favorites(ctx: Context, profile: String): List<Saved> {
        val arr = JSONArray(fav(ctx, profile).getString("list", "[]")!!)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Saved(o.getInt("id"), o.getString("type"), o.getString("name"), o.optString("poster").ifBlank { null }, o.optString("year"))
        }
    }

    fun isFavorite(ctx: Context, profile: String, id: Int) = favorites(ctx, profile).any { it.id == id }

    fun toggleFavorite(ctx: Context, profile: String, t: Title) {
        val items = favorites(ctx, profile).toMutableList()
        if (items.any { it.id == t.id }) items.removeAll { it.id == t.id }
        else items.add(0, Saved(t.id, t.type, t.name, t.poster, t.year))
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().put("id", it.id).put("type", it.type).put("name", it.name).put("poster", it.poster ?: "").put("year", it.year))
        }
        fav(ctx, profile).edit().putString("list", arr.toString()).apply()
    }

    fun saveProgress(ctx: Context, profile: String, p: Progress) {
        val raw = JSONObject(prog(ctx, profile).getString("map", "{}")!!)
        raw.put(
            p.key,
            JSONObject().put("tmdbId", p.tmdbId).put("type", p.type).put("name", p.name).put("poster", p.poster ?: "")
                .put("videoId", p.videoId).put("pos", p.positionMs).put("dur", p.durationMs).put("updated", p.updated)
        )
        prog(ctx, profile).edit().putString("map", raw.toString()).apply()
    }

    fun continueWatching(ctx: Context, profile: String): List<Progress> {
        val raw = JSONObject(prog(ctx, profile).getString("map", "{}")!!)
        val out = mutableListOf<Progress>()
        raw.keys().forEach { k ->
            val o = raw.getJSONObject(k)
            val dur = o.getLong("dur")
            val pos = o.getLong("pos")
            if (dur > 0 && pos.toDouble() / dur < 0.92 && pos > 15000) {
                out.add(
                    Progress(k, o.getInt("tmdbId"), o.getString("type"), o.getString("name"), o.optString("poster").ifBlank { null },
                        o.getString("videoId"), pos, dur, o.getLong("updated"))
                )
            }
        }
        return out.sortedByDescending { it.updated }
    }

    fun positionFor(ctx: Context, profile: String, key: String): Long {
        val raw = JSONObject(prog(ctx, profile).getString("map", "{}")!!)
        return if (raw.has(key)) raw.getJSONObject(key).getLong("pos") else 0L
    }
}
