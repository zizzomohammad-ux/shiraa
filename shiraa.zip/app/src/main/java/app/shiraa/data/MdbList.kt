package app.shiraa.data

import app.shiraa.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request

object MdbList {
    private val client = OkHttpClient()
    private val json = Json { ignoreUnknownKeys = true }

    private fun label(s: String) = when (s) {
        "imdb" -> "IMDb"
        "tmdb" -> "TMDB"
        "trakt" -> "Trakt"
        "letterboxd" -> "Letterboxd"
        "tomatoes" -> "RT"
        "metacritic" -> "MC"
        else -> s
    }

    suspend fun ratings(type: String, tmdbId: Int): String = withContext(Dispatchers.IO) {
        try {
            val t = if (type == "tv") "show" else "movie"
            val url = "https://api.mdblist.com/tmdb/$t/$tmdbId?apikey=${BuildConfig.MDBLIST_KEY}"
            client.newCall(Request.Builder().url(url).build()).execute().use { res ->
                val body = res.body?.string() ?: return@use ""
                val arr = json.parseToJsonElement(body).jsonObject["ratings"]?.jsonArray ?: return@use ""
                arr.mapNotNull { el ->
                    val o = el.jsonObject
                    val src = o["source"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null
                    val v = o["value"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null
                    if (v == "null") null else "${label(src)} $v"
                }.take(5).joinToString("  ·  ")
            }
        } catch (e: Exception) {
            ""
        }
    }
}
