package app.shiraa.data

import app.shiraa.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request

data class Title(
    val id: Int,
    val type: String,
    val name: String,
    val overview: String,
    val poster: String?,
    val backdrop: String?,
    val year: String
)

data class Episode(
    val number: Int,
    val name: String,
    val overview: String,
    val still: String?
)

object Tmdb {
    private val client = OkHttpClient()
    private val json = Json { ignoreUnknownKeys = true }
    private const val BASE = "https://api.themoviedb.org/3"
    private const val IMG = "https://image.tmdb.org/t/p"

    private suspend fun get(path: String, extra: String = ""): JsonObject =
        withContext(Dispatchers.IO) {
            val url = "$BASE$path?api_key=${BuildConfig.TMDB_KEY}&language=ar-SA$extra"
            val req = Request.Builder().url(url).build()
            client.newCall(req).execute().use { res ->
                json.parseToJsonElement(res.body!!.string()).jsonObject
            }
        }

    private fun parse(arr: JsonArray, defaultType: String): List<Title> =
        arr.mapNotNull { el ->
            val o = el.jsonObject
            val id = o["id"]?.jsonPrimitive?.intOrNull ?: return@mapNotNull null
            val type = o["media_type"]?.jsonPrimitive?.contentOrNull ?: defaultType
            if (type != "movie" && type != "tv") return@mapNotNull null
            val name = o["title"]?.jsonPrimitive?.contentOrNull
                ?: o["name"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null
            val date = o["release_date"]?.jsonPrimitive?.contentOrNull
                ?: o["first_air_date"]?.jsonPrimitive?.contentOrNull ?: ""
            Title(
                id = id,
                type = type,
                name = name,
                overview = o["overview"]?.jsonPrimitive?.contentOrNull ?: "",
                poster = o["poster_path"]?.jsonPrimitive?.contentOrNull?.let { "$IMG/w342$it" },
                backdrop = o["backdrop_path"]?.jsonPrimitive?.contentOrNull?.let { "$IMG/w780$it" },
                year = date.take(4)
            )
        }

    suspend fun trendingMovies() = parse(get("/trending/movie/week")["results"]!!.jsonArray, "movie")
    suspend fun trendingSeries() = parse(get("/trending/tv/week")["results"]!!.jsonArray, "tv")
    suspend fun popularMovies() = parse(get("/movie/popular")["results"]!!.jsonArray, "movie")
    suspend fun popularSeries() = parse(get("/tv/popular")["results"]!!.jsonArray, "tv")

    suspend fun search(q: String) =
        parse(get("/search/multi", "&query=${java.net.URLEncoder.encode(q, "UTF-8")}")["results"]!!.jsonArray, "movie")

    suspend fun imdbId(type: String, id: Int): String? {
        val o = if (type == "tv") get("/tv/$id/external_ids") else get("/movie/$id/external_ids")
        return o["imdb_id"]?.jsonPrimitive?.contentOrNull
    }

    suspend fun seasonCount(id: Int): Int {
        val o = get("/tv/$id")
        return o["number_of_seasons"]?.jsonPrimitive?.intOrNull ?: 1
    }

    suspend fun episodes(id: Int, season: Int): List<Episode> {
        val o = get("/tv/$id/season/$season")
        val arr = o["episodes"]?.jsonArray ?: return emptyList()
        return arr.map { el ->
            val e = el.jsonObject
            Episode(
                number = e["episode_number"]?.jsonPrimitive?.intOrNull ?: 0,
                name = e["name"]?.jsonPrimitive?.contentOrNull ?: "",
                overview = e["overview"]?.jsonPrimitive?.contentOrNull ?: "",
                still = e["still_path"]?.jsonPrimitive?.contentOrNull?.let { "$IMG/w300$it" }
            )
        }
    }

    suspend fun byId(type: String, id: Int): Title? {
        val o = get("/$type/$id")
        val name = o["title"]?.jsonPrimitive?.contentOrNull ?: o["name"]?.jsonPrimitive?.contentOrNull ?: return null
        val date = o["release_date"]?.jsonPrimitive?.contentOrNull ?: o["first_air_date"]?.jsonPrimitive?.contentOrNull ?: ""
        return Title(
            id = id, type = type, name = name,
            overview = o["overview"]?.jsonPrimitive?.contentOrNull ?: "",
            poster = o["poster_path"]?.jsonPrimitive?.contentOrNull?.let { "$IMG/w342$it" },
            backdrop = o["backdrop_path"]?.jsonPrimitive?.contentOrNull?.let { "$IMG/w780$it" },
            year = date.take(4)
        )
    }
}
