package app.shiraa.data

import android.content.Context

object AppSettings {
    private fun p(ctx: Context) = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun get(ctx: Context, key: String, def: String = ""): String = p(ctx).getString(key, def) ?: def

    fun set(ctx: Context, key: String, value: String) {
        p(ctx).edit().putString(key, value).apply()
    }

    fun subSize(ctx: Context): Float = get(ctx, "subSize", "20").toFloatOrNull() ?: 20f

    fun iptvLists(ctx: Context): List<String> =
        get(ctx, "iptv").split("\n").map { it.trim() }.filter { it.isNotBlank() }
}
