package app.shiraa.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request

data class StreamItem(val title: String, val url: String, val addon: String)

data class SubItem(val lang: String, val url: String)

object Addons {
    private val client = OkHttpClient()
    private val json = Json { ignoreUnknownKeys = true }

    fun list(ctx: Context, profile: String): List<String> {
        val sp = ctx.getSharedPreferences("addons_$profile", Context.MODE_PRIVATE)
        return sp.getStringSet("urls", emptySet())!!.toList()
    }

    fun add(ctx: Context, profile: String, manifestUrl: String) {
        val sp = ctx.getSharedPreferences("addons_$profile", Context.MODE_PRIVATE)
        val set = sp.getStringSet("urls", emptySet())!!.toMutableSet()
        set.add(normalize(manifestUrl))
        sp.edit().putStringSet("urls", set).apply()
    }

    fun remove(ctx: Context, profile: String, manifestUrl: String) {
        val sp = ctx.getSharedPreferences("addons_$profile", Context.MODE_PRIVATE)
        val set = sp.getStringSet("urls", emptySet())!!.toMutableSet()
        set.remove(manifestUrl)
        sp.edit().putStringSet("urls", set).apply()
    }

    private fun normalize(u: String): String =
        u.trim().replace("stremio://", "https://")

    private fun baseOf(manifestUrl: String): String =
        manifestUrl.removeSuffix("/manifest.json").trimEnd('/')

    private suspend fun fetch(url: String): String? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url(url).build()
            client.newCall(req).execute().use { res ->
                if (res.isSuccessful) res.body?.string() else null
            }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun streams(ctx: Context, profile: String, type: String, id: String): List<StreamItem> {
        val out = mutableListOf<StreamItem>()
        for (m in list(ctx, profile)) {
            val body = fetch("${baseOf(m)}/stream/$type/$id.json") ?: continue
            try {
                val arr = json.parseToJsonElement(body).jsonObject["streams"]?.jsonArray ?: continue
                for (el in arr) {
                    val o = el.jsonObject
                    val url = o["url"]?.jsonPrimitive?.contentOrNull ?: continue
                    val name = o["name"]?.jsonPrimitive?.contentOrNull ?: ""
                    val desc = o["title"]?.jsonPrimitive?.contentOrNull
                        ?: o["description"]?.jsonPrimitive?.contentOrNull ?: ""
                    out.add(StreamItem("$name\n$desc".trim(), url, m))
                }
            } catch (_: Exception) {}
        }
        return out
    }

    suspend fun subtitles(ctx: Context, profile: String, type: String, id: String): List<SubItem> {
        val out = mutableListOf<SubItem>()
        for (m in list(ctx, profile)) {
            val body = fetch("${baseOf(m)}/subtitles/$type/$id.json") ?: continue
            try {
                val arr = json.parseToJsonElement(body).jsonObject["subtitles"]?.jsonArray ?: continue
                for (el in arr) {
                    val o = el.jsonObject
                    val url = o["url"]?.jsonPrimitive?.contentOrNull ?: continue
                    val lang = o["lang"]?.jsonPrimitive?.contentOrNull ?: "und"
                    out.add(SubItem(lang, url))
                }
            } catch (_: Exception) {}
        }
        return out
    }
}
