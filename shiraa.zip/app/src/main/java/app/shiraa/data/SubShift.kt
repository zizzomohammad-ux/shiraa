package app.shiraa.data

import android.content.Context
import android.net.Uri
import androidx.media3.common.MimeTypes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File

data class ShiftedSub(val uri: Uri, val mime: String)

object SubShift {
    private val client = OkHttpClient()
    private val stamp = Regex("(\\d{2}):(\\d{2}):(\\d{2})([,.])(\\d{3})")

    private fun shift(text: String, offsetMs: Long): String =
        stamp.replace(text) { m ->
            val h = m.groupValues[1].toLong()
            val mi = m.groupValues[2].toLong()
            val s = m.groupValues[3].toLong()
            val ms = m.groupValues[5].toLong()
            var total = h * 3600000 + mi * 60000 + s * 1000 + ms + offsetMs
            if (total < 0) total = 0
            val nh = total / 3600000
            val nm = (total % 3600000) / 60000
            val ns = (total % 60000) / 1000
            val nms = total % 1000
            "%02d:%02d:%02d%s%03d".format(nh, nm, ns, m.groupValues[4], nms)
        }

    suspend fun prepare(ctx: Context, url: String, offsetMs: Long, tag: String): ShiftedSub? =
        withContext(Dispatchers.IO) {
            try {
                val bytes = client.newCall(Request.Builder().url(url).build()).execute().use { it.body?.bytes() }
                    ?: return@withContext null
                var text = String(bytes, Charsets.UTF_8)
                if (text.contains('\uFFFD')) text = String(bytes, charset("windows-1256"))
                val isVtt = text.trimStart('\uFEFF', ' ', '\n', '\r').startsWith("WEBVTT")
                val out = if (offsetMs == 0L) text else shift(text, offsetMs)
                val f = File(ctx.cacheDir, "sub_$tag." + (if (isVtt) "vtt" else "srt"))
                f.writeText(out, Charsets.UTF_8)
                ShiftedSub(Uri.fromFile(f), if (isVtt) MimeTypes.TEXT_VTT else MimeTypes.APPLICATION_SUBRIP)
            } catch (e: Exception) {
                null
            }
        }
}
