package app.shiraa.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

data class Room(
    val url: String,
    val title: String,
    val subs: List<SubItem>,
    val pos: Long,
    val playing: Boolean
)

object Party {
    private val client = OkHttpClient()
    private val JSON = "application/json".toMediaType()

    fun newCode(): String = (10000..99999).random().toString()

    private fun endpoint(ctx: Context, code: String): String? {
        val base = AppSettings.get(ctx, "firebase").trim().trimEnd('/')
        if (base.isBlank()) return null
        return "$base/rooms/$code.json"
    }

    suspend fun put(ctx: Context, code: String, r: Room): Boolean = withContext(Dispatchers.IO) {
        val url = endpoint(ctx, code) ?: return@withContext false
        try {
            val subs = JSONArray()
            r.subs.forEach { subs.put(it.lang + "|" + it.url) }
            val o = JSONObject()
                .put("url", r.url)
                .put("title", r.title)
                .put("subs", subs)
                .put("pos", r.pos)
                .put("playing", r.playing)
            val req = Request.Builder().url(url).put(o.toString().toRequestBody(JSON)).build()
            client.newCall(req).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            false
        }
    }

    suspend fun get(ctx: Context, code: String): Room? = withContext(Dispatchers.IO) {
        val url = endpoint(ctx, code) ?: return@withContext null
        try {
            client.newCall(Request.Builder().url(url).build()).execute().use { res ->
                val text = res.body?.string() ?: return@use null
                if (!res.isSuccessful || text.trim() == "null") return@use null
                val o = JSONObject(text)
                val subs = mutableListOf<SubItem>()
                val arr = o.optJSONArray("subs")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val s = arr.getString(i)
                        val idx = s.indexOf('|')
                        if (idx > 0) subs.add(SubItem(s.substring(0, idx), s.substring(idx + 1)))
                    }
                }
                Room(o.getString("url"), o.optString("title"), subs, o.optLong("pos"), o.optBoolean("playing"))
            }
        } catch (e: Exception) {
            null
        }
    }
}
