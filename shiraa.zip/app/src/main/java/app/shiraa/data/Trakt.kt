package app.shiraa.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

data class DeviceCode(
    val deviceCode: String,
    val userCode: String,
    val url: String,
    val interval: Int,
    val expiresIn: Int
)

object Trakt {
    private val client = OkHttpClient()
    private val JSON = "application/json".toMediaType()

    suspend fun startLogin(ctx: Context): DeviceCode? = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject().put("client_id", AppSettings.get(ctx, "traktId")).toString().toRequestBody(JSON)
            val req = Request.Builder().url("https://api.trakt.tv/oauth/device/code").post(body).build()
            client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) return@use null
                val o = JSONObject(r.body!!.string())
                DeviceCode(
                    o.getString("device_code"),
                    o.getString("user_code"),
                    o.getString("verification_url"),
                    o.getInt("interval"),
                    o.getInt("expires_in")
                )
            }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun pollToken(ctx: Context, d: DeviceCode): Boolean {
        var waited = 0
        var wait = d.interval
        while (waited < d.expiresIn) {
            delay(wait * 1000L)
            waited += wait
            val code = withContext(Dispatchers.IO) {
                try {
                    val body = JSONObject()
                        .put("code", d.deviceCode)
                        .put("client_id", AppSettings.get(ctx, "traktId"))
                        .put("client_secret", AppSettings.get(ctx, "traktSecret"))
                        .toString().toRequestBody(JSON)
                    val req = Request.Builder().url("https://api.trakt.tv/oauth/device/token").post(body).build()
                    client.newCall(req).execute().use { r ->
                        if (r.code == 200) {
                            val o = JSONObject(r.body!!.string())
                            AppSettings.set(ctx, "traktToken", o.getString("access_token"))
                        }
                        r.code
                    }
                } catch (e: Exception) {
                    -1
                }
            }
            when (code) {
                200 -> return true
                400 -> {}
                429 -> wait += 1
                else -> return false
            }
        }
        return false
    }

    fun loggedIn(ctx: Context) = AppSettings.get(ctx, "traktToken").isNotBlank()

    suspend fun markWatched(ctx: Context, type: String, tmdbId: Int, videoId: String) {
        val token = AppSettings.get(ctx, "traktToken")
        if (token.isBlank()) return
        withContext(Dispatchers.IO) {
            try {
                val ids = JSONObject().put("tmdb", tmdbId)
                val payload = JSONObject()
                val parts = videoId.split(":")
                if (type == "tv" && parts.size == 3) {
                    val ep = JSONObject().put("number", parts[2].toInt())
                    val season = JSONObject().put("number", parts[1].toInt()).put("episodes", JSONArray().put(ep))
                    val show = JSONObject().put("ids", ids).put("seasons", JSONArray().put(season))
                    payload.put("shows", JSONArray().put(show))
                } else {
                    payload.put("movies", JSONArray().put(JSONObject().put("ids", ids)))
                }
                val req = Request.Builder()
                    .url("https://api.trakt.tv/sync/history")
                    .header("Authorization", "Bearer $token")
                    .header("trakt-api-version", "2")
                    .header("trakt-api-key", AppSettings.get(ctx, "traktId"))
                    .post(payload.toString().toRequestBody(JSON))
                    .build()
                client.newCall(req).execute().close()
            } catch (_: Exception) {}
        }
    }
}
