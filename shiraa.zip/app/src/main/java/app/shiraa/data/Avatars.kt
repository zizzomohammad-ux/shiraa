package app.shiraa.data

import app.shiraa.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request

object Avatars {
    private val client = OkHttpClient()
    private val json = Json { ignoreUnknownKeys = true }

    private val queries = listOf(
        "Breaking Bad", "Game of Thrones", "Peaky Blinders", "Money Heist",
        "Stranger Things", "The Dark Knight", "Inception", "Joker",
        "Interstellar", "Squid Game", "Narcos", "Vikings"
    )

    suspend fun load(): List<String> = withContext(Dispatchers.IO) {
        val out = mutableListOf<String>()
        for (q in queries) {
            try {
                val url = "https://api.themoviedb.org/3/search/multi?api_key=${BuildConfig.TMDB_KEY}&query=${java.net.URLEncoder.encode(q, "UTF-8")}"
                val req = Request.Builder().url(url).build()
                client.newCall(req).execute().use { res ->
                    val body = res.body?.string() ?: return@use
                    val arr = json.parseToJsonElement(body).jsonObject["results"]?.jsonArray ?: return@use
                    val first = arr.firstOrNull()?.jsonObject ?: return@use
                    val p = first["poster_path"]?.jsonPrimitive?.contentOrNull ?: return@use
                    out.add("https://image.tmdb.org/t/p/w185$p")
                }
            } catch (_: Exception) {}
        }
        out
    }
}
