package app.shiraa.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

data class Channel(val name: String, val group: String, val logo: String?, val url: String)

object Iptv {
    private val client = OkHttpClient()

    suspend fun load(url: String): List<Channel> = withContext(Dispatchers.IO) {
        try {
            val text = client.newCall(Request.Builder().url(url).build()).execute().use { it.body?.string() ?: "" }
            parse(text)
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun attr(line: String, key: String): String {
        val m = Regex(key + "=\"([^\"]*)\"").find(line)
        return m?.groupValues?.get(1) ?: ""
    }

    fun parse(text: String): List<Channel> {
        val out = mutableListOf<Channel>()
        var name = ""
        var group = ""
        var logo: String? = null
        for (raw in text.lines()) {
            val line = raw.trim()
            if (line.startsWith("#EXTINF")) {
                name = line.substringAfterLast(",").trim()
                group = attr(line, "group-title")
                logo = attr(line, "tvg-logo").ifBlank { null }
            } else if (line.isNotEmpty() && !line.startsWith("#")) {
                if (name.isNotBlank()) out.add(Channel(name, group, logo, line))
                name = ""
            }
        }
        return out
    }
}
