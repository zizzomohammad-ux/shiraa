package app.shiraa.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

data class Profile(
    val id: String,
    val name: String,
    val avatar: String,
    val pinHash: String?
)

object Profiles {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("profiles", Context.MODE_PRIVATE)

    private fun hash(pin: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray())
        return d.joinToString("") { "%02x".format(it) }
    }

    fun list(ctx: Context): List<Profile> {
        val arr = JSONArray(prefs(ctx).getString("list", "[]")!!)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Profile(
                id = o.getString("id"),
                name = o.getString("name"),
                avatar = o.getString("avatar"),
                pinHash = if (o.has("pin")) o.getString("pin") else null
            )
        }
    }

    private fun save(ctx: Context, items: List<Profile>) {
        val arr = JSONArray()
        items.forEach {
            val o = JSONObject()
            o.put("id", it.id)
            o.put("name", it.name)
            o.put("avatar", it.avatar)
            if (it.pinHash != null) o.put("pin", it.pinHash)
            arr.put(o)
        }
        prefs(ctx).edit().putString("list", arr.toString()).apply()
    }

    fun add(ctx: Context, name: String, avatar: String, pin: String?) {
        val items = list(ctx).toMutableList()
        items.add(
            Profile(
                id = System.currentTimeMillis().toString(),
                name = name,
                avatar = avatar,
                pinHash = if (pin.isNullOrBlank()) null else hash(pin)
            )
        )
        save(ctx, items)
    }

    fun remove(ctx: Context, id: String) {
        save(ctx, list(ctx).filter { it.id != id })
    }

    fun checkPin(p: Profile, pin: String): Boolean = p.pinHash == null || p.pinHash == hash(pin)
}
