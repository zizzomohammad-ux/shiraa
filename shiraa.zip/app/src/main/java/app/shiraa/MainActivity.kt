package app.shiraa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import app.shiraa.data.Profile
import app.shiraa.ui.AppNav
import app.shiraa.ui.ProfilesScreen
import app.shiraa.ui.ShiraaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ShiraaTheme {
                var current by remember { mutableStateOf<Profile?>(null) }
                if (current == null) {
                    ProfilesScreen(onSelect = { current = it })
                } else {
                    AppNav(profile = current!!.id, onSwitchProfile = { current = null })
                }
            }
        }
    }
}
